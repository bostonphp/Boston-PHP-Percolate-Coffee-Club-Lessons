<!DOCTYPE html>
<html>
<head>
    <title>Thank You</title>
</head>
<body>
    <h1>Thank you</h1>
    <a href="index.php">Take another evaluation</a>
</body>
</html>
